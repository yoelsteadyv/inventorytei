export declare const defaultState: {
    groups: never[];
    items: never[];
    choices: never[];
    loading: boolean;
};
declare const rootReducer: (passedState: any, action: any) => object;
export default rootReducer;
//# sourceMappingURL=index.d.ts.map